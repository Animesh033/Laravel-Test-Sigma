<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <label>Edit Book</label>
            <span class="pull-right"><a href="<?php echo e(url('/books')); ?>">Back to book List</a></span>
            <form method="post" action="<?php echo e(route('books.update', $book->id)); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <div class="form-group">
                    <label>Book name</label>
                    <input type="text" name="name" value="<?php echo e($book->name); ?>" class="form-control" placeholder="Enter book name">
                </div>
                <div class="form-group">
                    <label>Book quantity</label>
                    <input type="number" name="quantity" value="<?php echo e($book->quantity); ?>" class="form-control" placeholder="Enter book quantity">
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select class="form-control" name="category">
                        <?php if(isset($categories) && count($categories) > 0): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $book->category ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <input type="submit" value="Update" class="btn btn-primary">
            </form>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sigma', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>